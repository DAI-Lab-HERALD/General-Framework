from experiment import Experiment

# Draw latex figure
Experiment_name = 'rounD_LR'
new_experiment = Experiment(Experiment_name)

#%% Select modules
# # Select the datasets
Data_sets = [{'scenario': 'Argoverse_Interactive', 'max_num_agents': None, 't0_type': 'all', 'conforming_t0_types': []}]

# Select the params for the datasets to be considered
Data_params = []
Data_params.append({'dt':                0.25, 
                    'num_timesteps_in':  (19, 20.6), 
                    'num_timesteps_out': (24, 24)})

# Select the spitting methods to be considered
Splitters = [{'Type': 'Cross_split', 'repetition': [0,1,2,3,4,5,6,7,8], 'test_part': 0.112}]

# Select the models to be trained
Models = ['adapt_aydemir', 'fjmp_rowe', 'autobot_girgis', 'wayformer_unitraj']

# Select the metrics to be used
Metrics = [{'metric': 'minADE_indep', 'kwargs': {'num_preds': 6}}, 
           {'metric': 'minADE_joint', 'kwargs': {'num_preds': 6}}, 
           {'metric': 'minFDE_indep', 'kwargs': {'num_preds': 6}},
           {'metric': 'minFDE_joint', 'kwargs': {'num_preds': 6}},
           'Miss_rate_indep']

new_experiment.set_modules(Data_sets, Data_params, Splitters, Models, Metrics)

#%% Other settings
# Set the number of different trajectories to be predicted by trajectory prediction models.
num_samples_path_pred = 20

# Deciding wether to enforce start times (or allow later predictions if not enough input data is available)
enforce_prediction_time = True

# determine if the upper bound for n_O should be enforced, or if prediction can be made without
# underlying output data (might cause training problems)
enforce_num_timesteps_out = True

# Determine if the useless prediction (i.e, prediction you cannot act anymore)
# should be exclude from the dataset
exclude_post_crit = True

# Decide wether missing position in trajectory data can be extrapolated
allow_extrapolation = False

# Use all available agents for predictions
agents_to_predict = 'all'

# Determine if allready existing results should be overwritten, or if not, be used instead
overwrite_results = 'no'

# Determine if the model should be evaluated on the training set as well
evaluate_on_train_set = False

# Determine if predictions should be saved
save_predictions = True

# Select method used for transformation function to path predictions
model_for_path_transform = 'trajectron_salzmann_old'

new_experiment.set_parameters(model_for_path_transform, num_samples_path_pred, 
                              enforce_num_timesteps_out, enforce_prediction_time, 
                              exclude_post_crit, allow_extrapolation, 
                              agents_to_predict, overwrite_results, 
                              save_predictions, evaluate_on_train_set)

#%% Run experiment
new_experiment.run() 

# Load results
Results = new_experiment.load_results(plot_if_possible = False)

print('Results shape:', Results.shape)
Results = Results.squeeze()
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)
print(Results)
np.save('Results_simulations_round_2.npy', Results)