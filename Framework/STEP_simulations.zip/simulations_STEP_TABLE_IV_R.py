from experiment import Experiment

# Draw latex figure
Experiment_name = 'rounD_LR'
new_experiment = Experiment(Experiment_name)

#%% Select modules
# # Select the datasets
Data_sets = []
perturbation_dict = {'attack': 'Adversarial_Control_Action',
                     'data_set_dict': {'scenario': 'RounD_round_about', 'max_num_agents': None, 't0_type': 'all', 'conforming_t0_types': []}, 
                     'data_param': {'dt': 0.25, 'num_timesteps_in':  (19, 20.6), 'num_timesteps_out': (24, 24)},
                     'splitter_dict': {'Type': 'Predefined_split'},
                     'model_dict': None,
                     'num_samples_perturb': 20,
                     'max_number_iterations': 50,
                     'alpha': 0.0025,
                     'gamma': 0.95,
                     'loss_function_1': 'FDE_Y_GT_Y_Pred_Max',
                     'loss_function_2': None,
                     'barrier_function_past': 'Time_Trajectory_specific_V2',
                     'barrier_function_future': 'Trajectory_specific_V2',
                     'distance_threshold_past': 0.5,
                     'distance_threshold_future': 0.5,
                     'log_value_past': 5,
                     'log_value_future': 5,
                     'GT_data': 'no'}
import copy
for attacked_model in [{'model': 'adapt_aydemir', 'kwargs': {'epoch': 250}}, 
                       {'model': 'fjmp_rowe', 'kwargs': {'max_epochs': 250}}, 
                       {'model': 'autobot_girgis', 'kwargs': {'max_epochs': 500, 'learning_rate_sched': [50, 100, 150, 200, 250]}}, 
                       {'model': 'wayformer_unitraj', 'kwargs': {'max_epochs': 500, 'learning_rate_sched': [50, 100, 150, 200, 250]}}]:
    for distance_thresholds in [0.25, 0.5, 1.0]:
        pertubation_dict_i = copy.deepcopy(perturbation_dict)
        pertubation_dict_i['distance_threshold_past'] = distance_thresholds
        pertubation_dict_i['distance_threshold_future'] = distance_thresholds
        pertubation_dict_i['model_dict'] = attacked_model
        Data_sets.append({'scenario': 'RounD_round_about', 'max_num_agents': None, 't0_type': 'all', 'conforming_t0_types': [], 'perturbation': pertubation_dict_i})

# Select the params for the datasets to be considered
Data_params = []
Data_params.append({'dt':                0.25, 
                    'num_timesteps_in':  (19, 20.6), 
                    'num_timesteps_out': (24, 24)})

# Select the spitting methods to be considered
Splitters = [{'Type': 'Predefined_split', 'test_pert': True}]

# Select the models to be trained
Models = [{'model': 'adapt_aydemir', 'kwargs': {'epoch': 250}},
          {'model': 'fjmp_rowe', 'kwargs': {'max_epochs': 250}}, 
          {'model': 'autobot_girgis', 'kwargs': {'max_epochs': 500, 'learning_rate_sched': [50, 100, 150, 200, 250]}},
          {'model': 'wayformer_unitraj', 'kwargs': {'max_epochs': 500, 'learning_rate_sched': [50, 100, 150, 200, 250]}}]


# Select the metrics to be used
Metrics = [{'metric': 'minADE_indep', 'kwargs': {'num_preds': 6}}, 
           {'metric': 'minADE_joint', 'kwargs': {'num_preds': 6}}, 
           {'metric': 'minFDE_indep', 'kwargs': {'num_preds': 6}},
           {'metric': 'minFDE_joint', 'kwargs': {'num_preds': 6}},
           'Miss_rate_indep', 
           'AUC_ROC', 
           'ECE_class']


new_experiment.set_modules(Data_sets, Data_params, Splitters, Models, Metrics)

#%% Other settings
# Set the number of different trajectories to be predicted by trajectory prediction models.
num_samples_path_pred = 20

# Deciding wether to enforce start times (or allow later predictions if not enough input data is available)
enforce_prediction_time = True

# determine if the upper bound for n_O should be enforced, or if prediction can be made without
# underlying output data (might cause training problems)
enforce_num_timesteps_out = True

# Determine if the useless prediction (i.e, prediction you cannot act anymore)
# should be exclude from the dataset
exclude_post_crit = True

# Decide wether missing position in trajectory data can be extrapolated
allow_extrapolation = False

# Use all available agents for predictions
agents_to_predict = 'all'

# Determine if allready existing results should be overwritten, or if not, be used instead
overwrite_results = 'no'

# Determine if the model should be evaluated on the training set as well
evaluate_on_train_set = False

# Determine if predictions should be saved
save_predictions = True

# Select method used for transformation function to path predictions
model_for_path_transform = 'trajectron_salzmann_old'

new_experiment.set_parameters(model_for_path_transform, num_samples_path_pred, 
                              enforce_num_timesteps_out, enforce_prediction_time, 
                              exclude_post_crit, allow_extrapolation, 
                              agents_to_predict, overwrite_results, 
                              save_predictions, evaluate_on_train_set)

#%% Run experiment
new_experiment.run() 

# Load results
Results = new_experiment.load_results(plot_if_possible = False)

print('Results shape:', Results.shape)
Results = Results.squeeze()
import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)
print(Results)
np.save('Results_simulations_round_4_1.npy', Results)
