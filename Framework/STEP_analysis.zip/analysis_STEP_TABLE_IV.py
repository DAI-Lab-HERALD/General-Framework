import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)

# Results trained on RounD and evaluated there
Results_R_R = np.load('Results_simulations_round_3_1.npy') # (num_models, num_metrics)
# Results trained on Argoverse and evaluated on RounD
Results_A_R = np.load('Results_simulations_round_3_2.npy') # (num_models, num_metrics)
# Results trained on Argoverse, finetuned on RounD and evaluated on RounD
Results_F_R = np.load('Results_simulations_round_3_3.npy') # (num_models, num_metrics)

# Results trained on RounD and evaluated there (perturbed test)
Results_R_R_pert = np.load('Results_simulations_round_4_1.npy') # (num_attack_models * num_perturb, num_models, num_metrics)
# Results trained on Argoverse and evaluated on RounD (perturbed test)
Results_A_R_pert = np.load('Results_simulations_round_4_2.npy') # (num_attack_models * num_perturb, num_models, num_metrics)
# Results trained on Argoverse, finetuned on RounD and evaluated on RounD (perturbed test)
Results_F_R_pert = np.load('Results_simulations_round_4_3.npy') # (num_attack_models * num_perturb, num_models, num_metrics)

Results_unperturbed = np.stack([Results_A_R, Results_F_R, Results_R_R], axis = 1) # (num_models, num_procedures, num_metrics)
Results_perturbed = np.stack([Results_A_R_pert, Results_F_R_pert, Results_R_R_pert], axis = 2) # (num_attack_models * num_perturb, num_models, num_procedures, num_metrics)
Results_perturbed = Results_perturbed.reshape(-1, 3, *Results_perturbed.shape[1:]) # (num_attack_models, num_perturb, num_models, num_procedures, num_metrics)

# Blow up Results_unperturbed to num_attack_models
Results_unperturbed = np.tile(Results_unperturbed[np.newaxis], (Results_perturbed.shape[0], 1, 1, 1)) # (num_attack_models, num_models, num_procedures, num_metrics)

Results = np.concatenate([Results_unperturbed[:, np.newaxis], Results_perturbed], axis = 1) # (num_attack_models, num_perturb, num_models, num_procedures, num_metrics)

# Write table. The outer rows is the num_models, the outer columns is num_attack_models, the inner rows is num_procedures, the inner columns is num_perturbations
metric_ind = 0
Results = Results[..., metric_ind] # (num_attack_models, num_perturb, num_models, num_procedures)

num_perturb, num_procedres = Results.shape[1], Results.shape[3]
# Start wrting the data part of a latex table (only data, no first column)
# End each outer row with \\ \midrule, except the last row, which should end with \\ \bottomrule
# The first column should be the model name (use standin <Model {i}> for the i-th model)
# Each cell will have three rows, with the upper being A_R, the middle being F_R, and the lower being R_R, and num_perturb columns

# Get boolean array indicating if for a given setting and metric, the model is the best (this means lowest value, except for AUC)
if metric_ind == 12:
    Ind_best_model = np.argmax(Results, axis = 2) # (num_attack_models, num_perturb, num_metrics)
else:
    Ind_best_model = np.argmin(Results, axis = 2) # (num_attack_models, num_perturb, num_metrics)
Best_model = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[0]):
    for j in range(Results.shape[1]):
        for k in range(Results.shape[3]):
            Best_model[i, j, Ind_best_model[i, j, k], k] = True

# Get boolean array indicating the best perturbation for a given model and metric
if metric_ind == 12:
    Ind_best_pert = np.argmax(Results, axis = 1) # (num_attack_models, num_models, num_metrics)
else:
    Ind_best_pert = np.argmin(Results, axis = 1)
Best_pert = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[0]):
    for j in range(Results.shape[2]):
        for k in range(Results.shape[3]):
            Best_pert[i, Ind_best_pert[i, j, k], j, k] = True


# Reorder the dimensions
Results = Results.transpose((2, 3, 0, 1)) # (num_models, num_procedures, num_attack_models, num_perturb)
Best_model = Best_model.transpose((2, 3, 0, 1)) # (num_models, num_procedures, num_attack_models, num_perturb)
Best_pert = Best_pert.transpose((2, 3, 0, 1)) # (num_models, num_procedures, num_attack_models, num_perturb)

# Collapse the first two dimensions
Results = Results.reshape(Results.shape[0] * Results.shape[1], Results.shape[2] * Results.shape[3]) # (num_models * num_procedures, num_attack_models * num_perturb)
Best_model = Best_model.reshape(Best_model.shape[0] * Best_model.shape[1], Best_model.shape[2] * Best_model.shape[3]) # (num_models * num_procedures, num_attack_models * num_perturb)
Best_pert = Best_pert.reshape(Best_pert.shape[0] * Best_pert.shape[1], Best_pert.shape[2] * Best_pert.shape[3]) # (num_models * num_procedures, num_attack_models * num_perturb)

# Do not repeat the unperturbed results
i_unperturbed = np.arange(0, Results.shape[1], num_perturb)
column_remove = i_unperturbed[1:]

Results = np.delete(Results, column_remove, axis = 1) # (num_models * num_procedures, num_attack_models * num_perturb - 1)
Best_model = np.delete(Best_model, column_remove, axis = 1) # (num_models * num_procedures, num_attack_models * num_perturb - 1)
Best_pert = np.delete(Best_pert, column_remove, axis = 1) # (num_models * num_procedures, num_attack_models * num_perturb - 1)


Results_std = []
for i in range(Results.shape[0]):
    if np.mod(i, num_procedres) == 0:
        ii = int(i / num_procedres) + 1
        Results_std.append('\multirow{3}{*}{<Model ' + str(ii) + '>} & A & ')
    elif np.mod(i, num_procedres) == 1:
        Results_std.append(' & AR & ')
    else:
        Results_std.append(' & R &')
    

    results_i = Results[i]
    best_model_i = Best_model[i]
    best_pert_i = Best_pert[i]

    for j in range(Results.shape[1]):
        results_str = '{:.3f}'.format(results_i[j])
        
        # if best model, make bold
        if best_model_i[j]:
            results_str = '\\textbf{' + results_str + '}'

        # # if best procedure, color red
        # if best_pert_i[j]:
        #     results_str = '\\textcolor{red}{' + results_str + '}'

        Results_std[i] += results_str

        if j < Results.shape[1] - 1:
            Results_std[i] += ' & '
        else:
            Results_std[i] += r' \\' + '\n'
    
    if np.mod(i, num_procedres) == 2:
        if i < Results.shape[0] - 1:
            Results_std[i] += '\\midrule\n'
        else:
            Results_std[i] += '\\bottomrule\n'
    
# Combine the rows
Results_std = ''.join(Results_std)
print(Results_std)
