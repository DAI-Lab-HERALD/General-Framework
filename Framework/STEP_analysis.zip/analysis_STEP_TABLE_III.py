import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)


# Results trained on RounD and evaluated there
Results_R_R = np.load('Results_simulations_round_3_1.npy') # (num_models, num_metrics)
# Results trained on Argoverse and evaluated on RounD
Results_A_R = np.load('Results_simulations_round_3_2.npy') # (num_models, num_metrics)
# Results trained on Argoverse, finetuned on RounD and evaluated on RounD
Results_F_R = np.load('Results_simulations_round_3_3.npy') # (num_models, num_metrics)

# Start wrting the data part of a latex table (only data, no first column)
# End each row with \\ \midrule, except the last row, which should end with \\ \bottomrule
# The first column should be the model name (use standin <Model {i}> for the i-th model)
# Each cell will have three rows, with the upper being A_R, the middle being F_R, and the lower being R_R
Results = np.stack([Results_A_R, Results_F_R, Results_R_R], axis = 1) # (num_models, num_procedures, num_metrics)
# Get boolean array indicating if for a given setting and metric, the model is the best (this means lowest value, except for AUC)
Ind_best_model = np.argmin(Results, axis = 0) # (num_procedures, num_metrics)
Ind_best_model[...,[-2]] = np.argmax(Results[...,[-2]], axis = 0) # AUC is best when highest
Best_model = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[1]):
    for j in range(Results.shape[2]):
        Best_model[Ind_best_model[i, j], i, j] = True

# Get boolean array indicating the best procedure for a given model and metric
Ind_best_procedure = np.argmin(Results, axis = 1) # (num_models, num_metrics)
Ind_best_procedure[...,[-2]] = np.argmax(Results[...,[-2]], axis = 1) # AUC is best when highest
Best_procedure = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[0]):
    for j in range(Results.shape[2]):
        Best_procedure[i, Ind_best_procedure[i, j], j] = True



# Collapse the first two dimensions
Results = Results.reshape(-1, Results.shape[2]) # (num_models * num_procedures, num_metrics)
Best_model = Best_model.reshape(-1, Best_model.shape[2]) # (num_models * num_procedures, num_metrics)
Best_procedure = Best_procedure.reshape(-1, Best_procedure.shape[2]) # (num_models * num_procedures, num_metrics)



Results_std = []
for i in range(Results.shape[0]):
    if np.mod(i, 3) == 0:
        ii = int(i / 3) + 1
        Results_std.append('\multirow{3}{*}{<Model ' + str(ii) + '>} & ')
    else:
        Results_std.append(' & ')

    results_i = Results[i]
    best_model_i = Best_model[i]
    best_procedure_i = Best_procedure[i]

    for j in range(Results.shape[1]):
        results_str = '{:.3f}'.format(results_i[j])
        
        # if best model, make bold
        if best_model_i[j]:
            results_str = '\\textbf{' + results_str + '}'

        # if best procedure, color red
        if best_procedure_i[j]:
            results_str = '\\textcolor{red}{' + results_str + '}'

        Results_std[i] += results_str

        if j < Results.shape[1] - 1:
            Results_std[i] += ' & '
        else:
            Results_std[i] += r' \\' + '\n'
    
    if np.mod(i, 3) == 2:
        if i < Results.shape[0] - 1:
            Results_std[i] += '\\midrule\n'
        else:
            Results_std[i] += '\\bottomrule\n'
    
# Combine the rows
Results_std = ''.join(Results_std)
print(Results_std)
