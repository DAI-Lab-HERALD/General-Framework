import numpy as np
from scipy.stats import ttest_rel
np.set_printoptions(precision=3, suppress=True, linewidth=400)


Results = np.load('Results_simulations_round_1.npy') # (num_params, num_models, num_metrics)
dt = []
time_in = []
past_times = [1.5, 4.5]
for past_time in past_times:
    for frequency in [0.5, 0.1, 0.25]:
        dt.append(frequency)
        time_in.append(past_time)
dt = np.array(dt)
time_in = np.array(time_in)

# Find the original comparison
Use_old = (dt == 0.25) & (time_in == 4.5)
Results = Results[Use_old] # (num_models, num_metrics)

Results_cv = np.load('Results_simulations_round_2.npy') # (num_splits, num_models, num_metrics)

# Get statistic significance for each model vs model comparison for each metric, use standard t-test with paired samples
T_stats, P_values = ttest_rel(Results_cv[:, np.newaxis], Results_cv[:, :, np.newaxis], axis = 0) # (num_models x num_models x num_metrics)

# Put metric first
T_stats = T_stats.transpose(2, 0, 1) # (num_models x num_models x num_metrics)
P_values = P_values.transpose(2, 0, 1) # (num_models x num_models x num_metrics

# Get one sided result:
P_values_one = P_values / 2
P_values_one[T_stats < 0] = 1 - P_values_one[T_stats < 0]

print('P-values of "Metric(row model) > Metric(column model)":\nEach matrix is for a given metric\n', P_values_one)

## Write latex code for boxplots 
width = 17.5
height = 3
num_models, num_metrics = Results_cv.shape[1:]
width_plot = width / num_metrics
width_plot_actual = width_plot - 1

Model_list = ['ADAPT', 'FJMP', 'AutoBot', 'Wayformer']
Metric_list = ['$\\text{minADE}_{6}\\downarrow$ [$m$]', '$\\text{minADE}_{J,6}\\downarrow$ [$m$]', '$\\text{minFDE}_{6}\\downarrow$ [$m$]', '$\\text{minFDE}_{J,6}\\downarrow$ [$m$]', '$\\text{Miss rate}_{6}\\downarrow$']
plot_string = '\\begin{tikzpicture}\n'

for i in range(num_metrics):
    results = Results_cv[:, :, i] # (num_splits, num_models)
    results_original = Results[:, :, i] # (1, num_models)
    # Get origin location
    origin_x = i * width_plot + 1
    origin_y = 0

    plot_string += '\\begin{axis}[\n'
    plot_string += '    at={(' + str(origin_x) + 'cm,' + str(origin_y) + 'cm)},\n'
    plot_string += '    width=' + str(width_plot_actual) + 'cm,\n'
    plot_string += '    height=' + str(height) + 'cm,\n'
    plot_string += '    scale only axis=true,\n'
    plot_string += '    axis lines = left,\n'
    plot_string += '    every axis label/.append style={font=\\footnotesize},\n'
    plot_string += '    every tick label/.append style={font=\\footnotesize},\n'
    plot_string += '    xmin=0,\n'
    plot_string += '    xmax=' + str(num_models) + ',\n'
    plot_string += '    xlabel={},\n'
    plot_string += '    xtick={'
    for j in range(num_models):
        plot_string += str(j + 0.5)
        if j < num_models - 1:
            plot_string += ', '
    plot_string += '},\n'
    plot_string += '    xticklabels={'
    for j in range(num_models):
        plot_string += Model_list[j]
        if j < num_models - 1:
            plot_string += ', '
    plot_string += '},\n'
    plot_string += '    xlabel style={yshift=0.15cm},\n'
    plot_string += '    x tick label style = {rotate=90, xshift = -0.00cm, align = right},\n'
    plot_string += '    xmajorgrids=false,\n'
    y_min = np.floor(np.nanmin(results) * 0.99)
    plot_string += '    ymin= ' + str(y_min) + ',\n'
    y_max = np.ceil(np.nanmax(results) * 1.01)
    plot_string += '    ymax= ' + str(y_max) + ',\n'
    if y_max > 1:
        plot_string += '    ytick={'
        for j in range(int(y_min), int(y_max) + 1):
            plot_string += str(j)
            if j < int(y_max):
                plot_string += ', '
        plot_string += '},\n'
        plot_string += '    yticklabels={'
        for j in range(int(y_min), int(y_max) + 1):
            plot_string += str(j)
            if j < int(y_max):
                plot_string += ', '
        plot_string += '},\n'
    else:
        plot_string += '    ytick={0.0, 0.25, 0.5, 0.75, 1.0},\n'
        plot_string += '    yticklabels={0.0, 0.25, 0.5, 0.75, 1.0},\n'
    plot_string += '    y tick label style = {rotate=90, xshift = -0.00cm, align = right},\n'
    plot_string += '    ylabel={' + Metric_list[i] + '},\n'
    plot_string += '    ylabel style={yshift=-0.15cm},\n'
    plot_string += '    ymajorgrids=true,\n'
    plot_string += '    clip mode=individual,\n'
    plot_string += '    set layers=Bowpark,\n'
    plot_string += '    boxplot/draw direction=y,\n'
    plot_string += '    boxplot/box extend=0.7,\n'
    plot_string += '    ]\n'


    # Go through each model
    for j in range(num_models):
        results_model = results[:, j] # (num_splits,)
        results_model_orig = results_original[0, j] # (1,)

        # Get the quantiles
        result_quantile = np.nanquantile(results_model, [0.0, 0.25, 0.5, 0.75, 1.0])
        if np.isnan(result_quantile).all():
            result_quantile = -1 * np.ones(5)

        # Draw the boxplot (black boundary, filled black!25)
        plot_string += '    \\addplot+[\n'
        plot_string += '        boxplot prepared={\n'
        plot_string += '            draw position = ' + str(j + 0.5) + ',\n'
        plot_string += '            lower whisker = ' + str(result_quantile[0]) + ',\n'
        plot_string += '            lower quartile = ' + str(result_quantile[1]) + ',\n'
        plot_string += '            median = ' + str(result_quantile[2]) + ',\n'
        plot_string += '            upper quartile = ' + str(result_quantile[3]) + ',\n'
        plot_string += '            upper whisker = ' + str(result_quantile[4]) + ',\n'
        plot_string += '        },\n'
        plot_string += '        fill=black!25,\n'
        plot_string += '        draw=black,\n'
        plot_string += '        solid,\n'
        plot_string += '    ] coordinates {};\n'
        plot_string += '\n'

        # Draw a red cross for the original result
        plot_string += '    \\addplot+[\n'
        plot_string += '        only marks,\n'
        plot_string += '        mark=x,\n'
        plot_string += '        color=red,\n'
        plot_string += '        mark size=2.5pt,\n'
        plot_string += '    ] coordinates {(' + str(j + 0.5) + ', ' + str(results_model_orig) + ')};\n'
        plot_string += '\n'




    plot_string += '\\end{axis}\n'
    plot_string += '\n'


# Finish the plot string
plot_string += '\\end{tikzpicture}\n'

# Write the plot string to a file
with open('variety_fill.tex', 'w') as f:
    f.write(plot_string)



# Splitting method should be the same as in the first round
Results_cv_mean = np.nanmean(Results_cv, axis = 0) # (num_models, num_metrics)
Results_cv_std = np.nanstd(Results_cv, axis = 0) # (num_models, num_metrics)

# Start wrting the data part of a latex table (only data, no first column)
# End each row with \\ \midrule, except the last row, which should end with \\ \bottomrule
# The first column should be the model name (use standin <Model {i}> for the i-th model)

Results_std = []
for i in range(Results_cv_mean.shape[0]):
    Results_std.append('<Model ' + str(i) + '> & ')

    results_mean_i = Results_cv_mean[i]
    results_std_i = Results_cv_std[i]

    for j in range(Results_cv_mean.shape[1]):
        mean_str = '{:.3f}'.format(results_mean_i[j])
        std_str = '{:.3f}'.format(results_std_i[j])

        results_str = mean_str + ' (' + std_str + ')'
        Results_std[i] += results_str

        if j < Results_cv_mean.shape[1] - 1:
            Results_std[i] += ' & '
        else:
            Results_std[i] += r' \\' + '\n'
    
    if i < Results_cv_mean.shape[0] - 1:
        Results_std[i] += '\\midrule\n'
    else:
        Results_std[i] += '\\bottomrule\n'
    
# Combine the rows
Results_std = ''.join(Results_std)
print(Results_std)
