import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)

Results = np.load('Results_simulations_round_1.npy')

dt = []
time_in = []
past_times = [1.5, 4.5]
fequencies = [0.5, 0.1, 0.25]
for past_time in past_times:
    for frequency in fequencies:
        dt.append(frequency)
        time_in.append(past_time)

dt = np.array(dt)
time_in = np.array(time_in)

i_sort = np.argsort(time_in - dt)

dt = dt[i_sort]
time_in = time_in[i_sort]
Results = Results[i_sort]

print('dt:', dt)
print('time_in:', time_in)
print(Results) # (num_params, num_models, num_metrics)

# Get the best input data
Ind_best_in = np.argmin(Results, axis = 0) # (num_models, num_metrics)
Best_in = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[1]):
    for j in range(Results.shape[2]):
        Best_in[Ind_best_in[i, j], i, j] = True

# Split up the num_params into the two past_times
Results = Results.reshape((len(past_times), len(fequencies), *Results.shape[1:])) # (num_past_times, num_frequencies, num_models, num_metrics)
Best_in = Best_in.reshape((len(past_times), len(fequencies), *Best_in.shape[1:])) # (num_past_times, num_frequencies, num_models, num_metrics)
dt = dt.reshape((len(past_times), len(fequencies)))[[0]]
time_in = time_in.reshape((len(past_times), len(fequencies)))[:,[0]]

# Get best model id
Ind_best = np.argmin(Results, axis = 2) # (num_past_times, num_frequencies, num_metrics)
# Transform into boolean array
Best = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[0]):
    for j in range(Results.shape[1]):
        for k in range(Results.shape[3]):
            Best[i, j, Ind_best[i, j, k], k] = True

# Transform results into a 2D array, so that we have a large grid with rows being the num_models and columsn being the num_metrics
# Then in each gridcell of this outer grid, we have a smaller grid, with rows being the num frequencies and columns being the num past_times
# So the final array shoudl be of shape (num_models * num_frequencies, num_metrics * num_past_times)
Results = Results.transpose((2, 1, 3, 0)) # (num_models, num_frequencies, num_metrics, num_past_times)
Best_in = Best_in.transpose((2, 1, 3, 0)) # (num_models, num_frequencies, num_metrics, num_past_times)
Best    = Best.transpose((2, 1, 3, 0)) # (num_models, num_frequencies, num_metrics, num_past_times)


# Combine the first tow dimensions
Results = Results.reshape((Results.shape[0] * Results.shape[1], Results.shape[2] * Results.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)
Best_in = Best_in.reshape((Best_in.shape[0] * Best_in.shape[1], Best_in.shape[2] * Best_in.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)
Best = Best.reshape((Best.shape[0] * Best.shape[1], Best.shape[2] * Best.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)

# Transform this into the string of a latex table, with an inserted "\midrule" between models and a "\bottomrule" after the last model
# For this, use the output format consistent with np.set_printoptions(precision=3, suppress=True)
# Start with the first row of data. If Best it True, instead of ... use \textbf{...}
Results_str = []
for i in range(Results.shape[0]):
    Results_str.append('')
    results_i = Results[i]
    best_i = Best[i]
    best_in_i = Best_in[i]
    for j in range(Results.shape[1]):
        # Make into the format of the printoptions
        result_str = '{:.3f}'.format(results_i[j])
        if best_i[j]:
            result_str= '\\textbf{' + result_str + '}'
        
        # If it is the best input data, color it in red
        if best_in_i[j]:
            result_str = '\\textcolor{red}{' + result_str + '}'


        Results_str[i] += result_str
        if j < Results.shape[1] - 1:
            Results_str[i] += ' & '
    Results_str[i] += ' \\\\ \n'
# Now insert the "\midrule" after each model
Results_str = [Results_str[i] + '\\midrule\n' if (np.mod(i, 3) == 2 and i < len(Results_str) - 1) else Results_str[i] for i in range(len(Results_str))]
# Now insert the "\bottomrule" after the last model
Results_str[-1] = Results_str[-1] + '\\bottomrule'

# Add the place for model names in an extra first column. Importantly, use \multirow{3}{*}{...} to make the model name span all the frequencies.
for i in range(0, len(Results_str)):
    if np.mod(i, dt.shape[1]) == 0:
        Results_str[i] = '\\multirow{3}{*}{<Model_' + str(int(i/dt.shape[1]) + 1) + '>} & ' + Results_str[i]
    else:
        Results_str[i] = ' & ' + Results_str[i]


# Now combine all strings into one
Results_str = ''.join(Results_str)

# print results, with linebreaks being actualized
print(Results_str)
