import numpy as np
np.set_printoptions(precision=3, suppress=True, linewidth=400)

Results = np.load('Results_simulations_round_1.npy')

dt = []
time_in = []
past_times = [1.5, 4.5]
fequencies = [0.5, 0.1, 0.25]
for past_time in past_times:
    for frequency in fequencies:
        dt.append(frequency)
        time_in.append(past_time)

dt = np.array(dt)
time_in = np.array(time_in)

i_sort = np.argsort(time_in - dt)

dt = dt[i_sort]
time_in = time_in[i_sort]
Results = Results[i_sort]

print('dt:', dt)
print('time_in:', time_in)
print(Results) # (num_params, num_models, num_metrics)

# TODO: Remove
# This is because originally, more metrics were computed, but only five are reporter in the paper
Results = Results[:, :, [4,6,5,7,8]] # (num_params, num_models, num_metrics)

# Get the best input data
Ind_best_in = np.argmin(Results, axis = 0) # (num_models, num_metrics)
Best_in = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[1]):
    for j in range(Results.shape[2]):
        Best_in[Ind_best_in[i, j], i, j] = True

# Split up the num_params into the two past_times
Results = Results.reshape((len(past_times), len(fequencies), *Results.shape[1:])) # (num_past_times, num_frequencies, num_models, num_metrics)
Best_in = Best_in.reshape((len(past_times), len(fequencies), *Best_in.shape[1:])) # (num_past_times, num_frequencies, num_models, num_metrics)
dt = dt.reshape((len(past_times), len(fequencies)))[[0]]
time_in = time_in.reshape((len(past_times), len(fequencies)))[:,[0]]

# Get best model id
Ind_best = np.argmin(Results, axis = 2) # (num_past_times, num_frequencies, num_metrics)
# Transform into boolean array
Best = np.zeros(Results.shape, dtype = bool)
for i in range(Results.shape[0]):
    for j in range(Results.shape[1]):
        for k in range(Results.shape[3]):
            Best[i, j, Ind_best[i, j, k], k] = True

# Transform results into a 2D array, so that we have a large grid with rows being the num_models and columsn being the num_metrics
# Then in each gridcell of this outer grid, we have a smaller grid, with rows being the num frequencies and columns being the num past_times
# So the final array shoudl be of shape (num_models * num_frequencies, num_metrics * num_past_times)
Results = Results.transpose((3, 1, 2, 0)) # (num_metrics, num_frequencies, num_models, num_past_times)
Best_in = Best_in.transpose((3, 1, 2, 0)) # (num_metrics, num_frequencies, num_models, num_past_times)
Best    = Best.transpose((3, 1, 2, 0)) # (num_metrics, num_frequencies, num_models, num_past_times)

Model_names = [
    'ADAPT~\\cite{aydemir_adapt_2023}',
    'FJMP~\\cite{rowe_fjmp_2023}',
    'AutoBot~\\cite{girgis_latent_2022}',
    'Wayformer~\\cite{nayakanti_wayformer_2023}'
]

Metric_names = [
    '$\\text{minADE}_6 \\downarrow$',
    '$\\text{minADE}_{J,6} \\downarrow$',
    '$\\text{minFDE}_6 \\downarrow$',
    '$\\text{minFDE}_{J,6} \\downarrow$',
    '$\\text{MR}_6 \\downarrow$',
]
assert len(Model_names) == Results.shape[2], 'Number of model names does not match number of models in results'
assert len(Metric_names) == Results.shape[0], 'Number of metric names does not match number of metrics in results'

# Combine the two row dimensions
Results = Results.reshape((Results.shape[0], Results.shape[1], Results.shape[2] * Results.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)
Best_in = Best_in.reshape((Best_in.shape[0], Best_in.shape[1], Best_in.shape[2] * Best_in.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)
Best = Best.reshape((Best.shape[0], Best.shape[1], Best.shape[2] * Best.shape[3])) # (num_models * num_frequencies, num_metrics * num_past_times)

# Transform this into the string of a latex table, with an inserted "\midrule" between models and a "\bottomrule" after the last model
# For this, use the output format consistent with np.set_printoptions(precision=3, suppress=True)
# Start with the first row of data. If Best it True, instead of ... use \textbf{...}
Results_str = ''
# Go over metrics
for i in range(Results.shape[0]):
    Results_str += '\\begin{subtable}{\\textwidth}'
    Results_str += '\\centering\n'
    Results_str += '\\caption{The results for ' + Metric_names[i] + '.}\n'
    Results_str += '\\begin{tabular}{|r' + len(Model_names) * '|cc' + '|}\n'
    Results_str += '\\toprule\n'
    # Start the first label row 
    Results_str += 'Model & '
    # Go through models
    for model_name in Model_names:
        Results_str += '\\multicolumn{' + str(time_in.shape[0]) + '}{c|}{' + model_name + '} & '
    # Remove last " & "
    Results_str = Results_str[:-3] + ' \\\\ \n'

    # Do the second row with the labels
    # First cell is bound to the left
    Results_str += '\\multicolumn{1}{|l|}{$\\delta t$ / $T_I$} & '
    time_in_str = ''.join([f'\\SI{{{time_in[i,0]}}}{{s}} & ' for i in range(time_in.shape[0])])
    Results_str += len(Model_names) * time_in_str
    Results_str = Results_str[:-3] + ' \\\\ \n'
    Results_str += '\\midrule\n'

    # Get the actual data rows
    for j in range(Results.shape[1]):
        # Add the dt value
        Results_str += f'\\SI{{{dt[0, j]}}}{{s}} & '
        results_i = Results[i,j]
        best_i = Best[i,j]
        best_in_i = Best_in[i,j]
        # go over columns of the table
        for k in range(Results.shape[2]):
            # Make into the format of the printoptions
            result_str = '{:.3f}'.format(results_i[k])
            if best_i[k]:
                result_str= '\\textbf{' + result_str + '}'
            
            # If it is the best input data, color it in red
            if best_in_i[k]:
                result_str = '\\underline{' + result_str + '}'


            Results_str += result_str
            if k < Results.shape[2] - 1:
                Results_str += ' & '
            else:
                Results_str += ' \\\\ \n'
    Results_str += '\\bottomrule\n'
    Results_str += '\\end{tabular}\n'
    Results_str += '\\end{subtable}\n'

    if i < Results.shape[0] - 1:
        Results_str += '\\vfill\n\n'

# print results, with linebreaks being actualized
print(Results_str)
